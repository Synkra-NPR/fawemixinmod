package com.synkra.fawemixinmod.mixin.tacz;


import com.google.common.collect.Lists;
import com.google.gson.annotations.SerializedName;
import com.synkra.fawemixinmod.tacz.util.DurabilityUtil;
import com.tacz.guns.api.GunProperties;
import com.tacz.guns.api.modifier.CacheValue;
import com.tacz.guns.api.modifier.IAttachmentModifier;
import com.tacz.guns.api.modifier.JsonProperty;
import com.tacz.guns.api.modifier.ParameterizedCachePair;
import com.tacz.guns.resource.CommonAssetsManager;
import com.tacz.guns.resource.modifier.AttachmentCacheProperty;
import com.tacz.guns.resource.modifier.AttachmentPropertyManager;
import com.tacz.guns.resource.modifier.custom.RecoilModifier;
import com.tacz.guns.resource.pojo.data.attachment.Modifier;
import com.tacz.guns.resource.pojo.data.gun.GunData;
import com.tacz.guns.resource.pojo.data.gun.GunRecoil;
import com.tacz.guns.resource.pojo.data.gun.GunRecoilKeyFrame;
import it.unimi.dsi.fastutil.Pair;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;

@Mixin(RecoilModifier.class)
public class RecoilModifierMixinOverwrite {
    @Shadow(remap = false)
    private static float getMaxInGunRecoilKeyFrame(GunRecoilKeyFrame[] frames) {
        throw new AbstractMethodError();
    }
    /**
     * @author Synkra
     * @reason 修正后坐力
     */
    @Overwrite(remap = false)
    @OnlyIn(Dist.CLIENT)
    public List<IAttachmentModifier.DiagramsData> getPropertyDiagramsData(ItemStack gunItem, GunData gunData, AttachmentCacheProperty cacheProperty) {
        ParameterizedCachePair<Float, Float> propertyCache = cacheProperty.getCache(RecoilModifier.ID);
        GunRecoil recoil = gunData.getRecoil();

        // 获取原始后坐力值
        double pitch = propertyCache.left().getDefaultValue();
        double yaw = propertyCache.right().getDefaultValue();

        // 应用耐久度对后坐力的影响
        float recoilMultiplier = DurabilityUtil.getRecoilMultiplier(gunItem);
        pitch *= recoilMultiplier;
        yaw *= recoilMultiplier;

        double modifiedPitch = propertyCache.left().eval(getMaxInGunRecoilKeyFrame(recoil.getPitch()));
        double modifiedYaw = propertyCache.right().eval(getMaxInGunRecoilKeyFrame(recoil.getYaw()));

        // 应用耐久度对后坐力的影响
        modifiedPitch *= recoilMultiplier*10;
        modifiedYaw *= recoilMultiplier*10;

        double pitchModifier = modifiedPitch - pitch;
        double pitchPercent = Math.min(pitch / 5.0, 1);
        double pitchModifierPercent = Math.min(pitchModifier / 5.0, 1);
        String pitchTitleKey = "gui.tacz.gun_refit.property_diagrams.pitch";
        String pitchPositivelyString = String.format("%.2f §c(+%.2f)", modifiedPitch, pitchModifier);
        String pitchNegativelyString = String.format("%.2f §a(%.2f)", modifiedPitch, pitchModifier);
        String pitchDefaultString = String.format("%.2f", modifiedPitch);



        double yawModifier = modifiedYaw - yaw;
        double yawPercent = Math.min(yaw / 5.0, 1);
        double yawModifierPercent = Math.min(yawModifier / 5.0, 1);
        String yawTitleKey = "gui.tacz.gun_refit.property_diagrams.yaw";
        String yawPositivelyString = String.format("%.2f §c(+%.2f)", modifiedYaw, yawModifier);
        String yawNegativelyString = String.format("%.2f §a(%.2f)", modifiedYaw, yawModifier);
        String yawDefaultString = String.format("%.2f", modifiedYaw);

        boolean positivelyBetter = false;

        IAttachmentModifier.DiagramsData pitchData = new IAttachmentModifier.DiagramsData(pitchPercent, pitchModifierPercent, pitchModifier, pitchTitleKey, pitchPositivelyString, pitchNegativelyString, pitchDefaultString, positivelyBetter);
        IAttachmentModifier.DiagramsData yawData = new IAttachmentModifier.DiagramsData(yawPercent, yawModifierPercent, yawModifier, yawTitleKey, yawPositivelyString, yawNegativelyString, yawDefaultString, positivelyBetter);
        return List.of(pitchData, yawData);
    }
}
