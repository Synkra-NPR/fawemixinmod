package com.synkra.fawemixinmod.mixin.tacz;

import com.synkra.fawemixinmod.tacz.util.DurabilityUtil;
import com.tacz.guns.api.GunProperties;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.gun.FireMode;
import com.tacz.guns.api.modifier.IAttachmentModifier;
import com.tacz.guns.resource.modifier.AttachmentCacheProperty;
import com.tacz.guns.resource.modifier.custom.InaccuracyModifier;
import com.tacz.guns.resource.pojo.data.gun.GunData;
import com.tacz.guns.resource.pojo.data.gun.GunFireModeAdjustData;
import com.tacz.guns.resource.pojo.data.gun.InaccuracyType;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@Mixin(InaccuracyModifier.class)
public abstract class InaccuracyModifierMixin {

    /**
     * @author YourName
     * @reason 添加耐久度对散布的影响并修改方法签名
     */
    @Overwrite(remap = false)
    public List<IAttachmentModifier.DiagramsData> getPropertyDiagramsData(ItemStack gunItem, GunData gunData, AttachmentCacheProperty cacheProperty) {
        IGun iGun = Objects.requireNonNull(IGun.getIGunOrNull(gunItem));
        FireMode fireMode = iGun.getFireMode(gunItem);
        GunFireModeAdjustData fireModeAdjustData = gunData.getFireModeAdjustData(fireMode);

        return List.of(
                buildNormalModified(gunData, cacheProperty, fireModeAdjustData, gunItem, InaccuracyType.STAND, "gui.tacz.gun_refit.property_diagrams.hipfire_inaccuracy", 10.0),
                buildNormalModified(gunData, cacheProperty, fireModeAdjustData, gunItem, InaccuracyType.SNEAK, "gui.tacz.gun_refit.property_diagrams.sneak_inaccuracy", 5.0),
                buildNormalModified(gunData, cacheProperty, fireModeAdjustData, gunItem, InaccuracyType.LIE, "gui.tacz.gun_refit.property_diagrams.lie_inaccuracy", 5.0),
                buildAimModified(gunData, cacheProperty, fireModeAdjustData, gunItem)
        );
    }

    /**
     * @author YourName
     * @reason 修改后的buildNormal方法，包含ItemStack参数
     */
    @Overwrite(remap = false)
    private @NotNull IAttachmentModifier.DiagramsData buildNormal(GunData gunData, AttachmentCacheProperty cacheProperty, GunFireModeAdjustData fireModeAdjustData,
                                                                  InaccuracyType type, String titleKey, double referenceValue) {
        // 调用新的方法，传入一个null作为ItemStack（保持兼容性）
        return buildNormalModified(gunData, cacheProperty, fireModeAdjustData, null, type, titleKey, referenceValue);
    }

    /**
     * 新增的方法，包含ItemStack参数
     */
    private @NotNull IAttachmentModifier.DiagramsData buildNormalModified(GunData gunData, AttachmentCacheProperty cacheProperty, GunFireModeAdjustData fireModeAdjustData,
                                                                          ItemStack gunItem, InaccuracyType type, String titleKey, double referenceValue) {
        // 腰射扩散
        float inaccuracy = gunData.getInaccuracy(type);
        if (fireModeAdjustData != null) {
            inaccuracy += fireModeAdjustData.getOtherInaccuracy();
        }

        // 应用耐久度对散布的影响（如果gunItem不为null）
        if (gunItem != null) {
            inaccuracy *= DurabilityUtil.getInaccuracyMultiplier(gunItem);
        }

        float modifiedValue = cacheProperty.<Map<InaccuracyType, Float>>getCache(GunProperties.INACCURACY.name()).get(type);

        // 应用耐久度对散布的影响（如果gunItem不为null）
        if (gunItem != null) {
            modifiedValue *= DurabilityUtil.getInaccuracyMultiplier(gunItem);
        }

        // 差值
        float inaccuracyModifier = modifiedValue - inaccuracy;
        // 默认值百分比
        double standInaccuracyPercent = Math.min(inaccuracy / referenceValue, 1);
        // 差值百分比
        double inaccuracyModifierPercent = Math.min(inaccuracyModifier / referenceValue, 1);

        String positivelyString = String.format("%.2f §c(+%.2f)", modifiedValue, inaccuracyModifier);
        String negativelyString = String.format("%.2f §a(%.2f)", modifiedValue, inaccuracyModifier);
        String defaultString = String.format("%.2f", modifiedValue);
        boolean positivelyBetter = false;

        return new IAttachmentModifier.DiagramsData(standInaccuracyPercent, inaccuracyModifierPercent, inaccuracyModifier,
                titleKey, positivelyString, negativelyString, defaultString, positivelyBetter);
    }

    /**
     * @author YourName
     * @reason 修改后的buildAim方法，包含ItemStack参数
     */
    @Overwrite(remap = false)
    private @NotNull IAttachmentModifier.DiagramsData buildAim(GunData gunData, AttachmentCacheProperty cacheProperty, GunFireModeAdjustData fireModeAdjustData) {
        // 调用新的方法，传入一个null作为ItemStack（保持兼容性）
        return buildAimModified(gunData, cacheProperty, fireModeAdjustData, null);
    }

    /**
     * 新增的方法，包含ItemStack参数
     */
    private @NotNull IAttachmentModifier.DiagramsData buildAimModified(GunData gunData, AttachmentCacheProperty cacheProperty, GunFireModeAdjustData fireModeAdjustData, ItemStack gunItem) {
        float aimInaccuracy = gunData.getInaccuracy(InaccuracyType.AIM);
        if (fireModeAdjustData != null) {
            aimInaccuracy += fireModeAdjustData.getAimInaccuracy();
        }

        // 应用耐久度对散布的影响（如果gunItem不为null）
        if (gunItem != null) {
            aimInaccuracy *= DurabilityUtil.getInaccuracyMultiplier(gunItem);
        }

        aimInaccuracy = 1f - aimInaccuracy;
        float modifiedValue = cacheProperty.<Map<InaccuracyType, Float>>getCache(GunProperties.INACCURACY.name()).get(InaccuracyType.AIM);

        // 应用耐久度对散布的影响（如果gunItem不为null）
        if (gunItem != null) {
            modifiedValue *= DurabilityUtil.getInaccuracyMultiplier(gunItem);
        }
        modifiedValue = 1 - modifiedValue;

        aimInaccuracy = Mth.clamp(aimInaccuracy, 0f, 1f);
        modifiedValue = Mth.clamp(modifiedValue, 0f, 1f);

        float inaccuracyModifier = modifiedValue - aimInaccuracy;

        double aimInaccuracyPercent = Mth.clamp(aimInaccuracy, 0f, 1f);
        double inaccuracyModifierPercent = Mth.clamp(inaccuracyModifier, 0f, 1f);

        String titleKey = "gui.tacz.gun_refit.property_diagrams.aim_inaccuracy";
        String positivelyString = String.format("%.1f%% §a(+%.1f%%)", modifiedValue * 100, inaccuracyModifier * 100);
        String negativelyString = String.format("%.1f%% §c(%.1f%%)", modifiedValue * 100, inaccuracyModifier * 100);
        String defaultString = String.format("%.1f%%", modifiedValue * 100);
        boolean positivelyBetter = true;

        return new IAttachmentModifier.DiagramsData(aimInaccuracyPercent, inaccuracyModifierPercent, inaccuracyModifier,
                titleKey, positivelyString, negativelyString, defaultString, positivelyBetter);
    }
}