package com.synkra.fawemixinmod.mixin.tacz;

import com.synkra.fawemixinmod.tacz.GunRankingManager;
import com.tacz.guns.entity.EntityKineticBullet;
import com.tacz.guns.resource.pojo.data.gun.ExtraDamage;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.LinkedList;

@Mixin(EntityKineticBullet.class)
public class EntityKineticBulletMixinOverwrite extends ProjectileMixin {
    @Shadow(remap = false)
    private Vec3 startPos;
    @Shadow(remap = false)
    private LinkedList<ExtraDamage.DistanceDamagePair> damageAmount;
    @Shadow(remap = false)
    private float distanceAmount;
    @Shadow(remap = false)
    private float damageModifier;
    @Shadow(remap = false)
    private ResourceLocation gunId;
    /**
     * @author Synkra
     * @reason 根据枪械稀有度调整伤害，仅当射击者是玩家时应用稀有度修正
     */
    @Overwrite(remap = false)
    public float getDamage(Vec3 hitVec) {
        // 遍历进行判断
        double playerDistance = hitVec.distanceTo(this.startPos);
        for (ExtraDamage.DistanceDamagePair pair : this.damageAmount) {
            float effectiveDistance = this.damageAmount.get(0).getDistance() == pair.getDistance() ? this.distanceAmount : pair.getDistance();
            if (playerDistance < effectiveDistance) {
                float damage = pair.getDamage();

                // 根据枪械稀有度调整伤害，仅当射击者是玩家时应用稀有度修正
                float damageMultiplier = 1.0f;
                Entity owner = this.getOwner();
                if (owner instanceof Player) {
                    damageMultiplier = GunRankingManager.getDamageMultiplier(GunRankingManager.getGunRarity(this.gunId));
                }
                return Math.max(damage * this.damageModifier * damageMultiplier, 0F);
            }
        }
        // 如果忘记写最大值，那我就直接认为你伤害为 0
        return 0;
    }
}
