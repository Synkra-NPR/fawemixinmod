package com.synkra.fawemixinmod.mixin.tacz;

import com.synkra.fawemixinmod.tacz.util.DurabilityUtil;
import com.tacz.guns.api.entity.IGunOperator;
import com.tacz.guns.api.entity.ReloadState;
import com.tacz.guns.entity.EntityKineticBullet;
import com.tacz.guns.entity.shooter.ShooterDataHolder;
import com.tacz.guns.item.ModernKineticGunItem;
import com.tacz.guns.item.ModernKineticGunScriptAPI;
import com.tacz.guns.resource.index.CommonGunIndex;
import com.tacz.guns.resource.modifier.AttachmentCacheProperty;
import com.tacz.guns.resource.pojo.data.gun.*;
import com.tacz.guns.resource.modifier.custom.InaccuracyModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector2d;
import org.luaj.vm2.*;
import org.luaj.vm2.lib.jse.CoerceJavaToLua;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.*;

@Mixin(ModernKineticGunItem.class)
public class ModernKineticGunItemMixinOverwrite {
    @Shadow(remap = false)
    private LuaFunction checkFunction(LuaValue luaValue) {
        throw new AbstractMethodError();
    }
    @Shadow(remap = false)
    private ReloadState defaultTickReload(ModernKineticGunScriptAPI api) {
        throw new AbstractMethodError();
    }
    /**
     * @author Synkra
     * @reason 应用耐久度对枪的影响
     */
    @Overwrite(remap = false)
    public void doBulletSpread(ShooterDataHolder dataHolder, ItemStack gunItem, LivingEntity shooter, Projectile projectile,
                               int bulletCnt, float processedSpeed, float inaccuracy, float pitch, float yaw) {
        if (!(projectile instanceof EntityKineticBullet bullet)) {
            return;
        }
        ModernKineticGunScriptAPI api = new ModernKineticGunScriptAPI();
        api.setItemStack(gunItem);
        api.setShooter(shooter);
        api.setDataHolder(dataHolder);

        CommonGunIndex gunIndex = api.getGunIndex();
        if (gunIndex == null) {
            return;
        }

        // 获取修改后的散布值
        float modifiedInaccuracy = inaccuracy;
        IGunOperator gunOperator = IGunOperator.fromLivingEntity(shooter);
        AttachmentCacheProperty cacheProperty = gunOperator.getCacheProperty();
        if (cacheProperty != null) {
            // 应用配件和耐久度对散布的修改
            InaccuracyType inaccuracyType = InaccuracyType.getInaccuracyType(shooter);
            Map<InaccuracyType, Float> inaccuracyMap = cacheProperty.getCache(InaccuracyModifier.ID);
            if (inaccuracyMap != null && inaccuracyMap.containsKey(inaccuracyType)) {
                // 应用耐久度对散布的影响
                modifiedInaccuracy = inaccuracyMap.get(inaccuracyType)* DurabilityUtil.getInaccuracyMultiplier(gunItem);
            }
        }

        float finalModifiedInaccuracy = modifiedInaccuracy;
        Optional.ofNullable(gunIndex.getScript())
                .map(script -> checkFunction(script.get("calcSpread")))
                .map(func -> func.call(CoerceJavaToLua.coerce(api) , LuaValue.valueOf(bulletCnt), LuaValue.valueOf(finalModifiedInaccuracy)))
                .map(luaValue -> {
                    if (luaValue.istable()){
                        LuaTable table = luaValue.checktable();
                        return new Vector2d(table.get(1).checkdouble(), table.get(2).checkdouble());
                    }
                    return null;
                }).ifPresentOrElse(vector2d -> {
                    bullet.shootFromRotation(shooter, pitch, yaw, 0.0F, processedSpeed, vector2d);
                },() -> {
                    bullet.shootFromRotation(shooter, pitch, yaw, 0.0F, processedSpeed, finalModifiedInaccuracy);
                });
    }

    /**
     * @author Synkra
     * @reason 修复bug
     */
    @Overwrite(remap = false)
    public ReloadState tickReload(ShooterDataHolder dataHolder, ItemStack gunItem, LivingEntity shooter) {
        ModernKineticGunScriptAPI api = new ModernKineticGunScriptAPI();
        api.setItemStack(gunItem);
        api.setShooter(shooter);
        api.setDataHolder(dataHolder);

        CommonGunIndex gunIndex = api.getGunIndex();
        if (gunIndex == null) {
            return new ReloadState();
        }
        return Optional.ofNullable(gunIndex.getScript())
                .map(script -> checkFunction(script.get("tick_reload")))
                .map(func -> {
                    ReloadState reloadState = new ReloadState();
                    try {
                        Varargs varargs = func.invoke(CoerceJavaToLua.coerce(api));
                        int typeOrdinary = varargs.arg(1).checkint();
                        long countDown = varargs.arg(2).checklong();
                        reloadState.setStateType(ReloadState.StateType.values()[typeOrdinary]);
                        reloadState.setCountDown(countDown);
                    } catch (LuaError e) {
                        // 如果Lua脚本执行出错，回退到默认实现
                        ReloadState defaultState = defaultTickReload(api);
                        reloadState.setStateType(defaultState.getStateType());
                        reloadState.setCountDown(defaultState.getCountDown());
                    }
                    return reloadState;
                })
                .orElseGet(() -> defaultTickReload(api));
    }
}