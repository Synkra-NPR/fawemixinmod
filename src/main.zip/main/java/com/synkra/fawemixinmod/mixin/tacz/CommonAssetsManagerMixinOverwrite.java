package com.synkra.fawemixinmod.mixin.tacz;

import com.synkra.fawemixinmod.tacz.api.event.common.GunRecipeInterceptEvent;
import com.tacz.guns.crafting.GunSmithTableRecipe;
import com.tacz.guns.init.ModRecipe;
import com.tacz.guns.resource.CommonAssetsManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TagsUpdatedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;

@Mixin(CommonAssetsManager.class)
public class CommonAssetsManagerMixinOverwrite {
    @Shadow(remap = false)
    public static CommonAssetsManager getInstance() {
        throw new AbstractMethodError();
    }
    /**
     * @author Synkra
     * @reason 取消枪械配方注册
     */
    @SubscribeEvent
    @Overwrite(remap = false)
    public static void onReload(TagsUpdatedEvent event) {
        if (event.getUpdateCause() == TagsUpdatedEvent.UpdateCause.SERVER_DATA_LOAD){
            if (getInstance() !=null && getInstance().recipeManager != null) {
                List<GunSmithTableRecipe> recipes = getInstance().recipeManager.getAllRecipesFor(ModRecipe.GUN_SMITH_TABLE_CRAFTING.get());
                for (GunSmithTableRecipe recipe : recipes) {
                    // 触发 GunRecipeInterceptEvent 事件，允许取消配方注册
                    GunRecipeInterceptEvent interceptEvent = new GunRecipeInterceptEvent(recipe.getId(), recipe);
                    if (!MinecraftForge.EVENT_BUS.post(interceptEvent) && !interceptEvent.isCanceled()) {
                        recipe.init();
                    }
                }
            }
        }
    }
}
