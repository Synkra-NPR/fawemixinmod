package com.synkra.fawemixinmod.mixin.tacz;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(Entity.class)
public class EntityMixin {
    @Shadow
    public Level level() {
        throw new AbstractMethodError();
    }
}
