package com.synkra.fawemixinmod.mixin.tacz;

import com.synkra.fawemixinmod.tacz.GunDurabilityManager;
import com.synkra.fawemixinmod.tacz.GunRankingManager;
import com.synkra.fawemixinmod.tacz.GunRarity;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.builder.AttachmentItemBuilder;
import com.tacz.guns.api.item.builder.GunItemBuilder;
import com.tacz.guns.api.item.gun.AbstractGunItem;
import com.tacz.guns.api.item.gun.GunItemManager;
import com.tacz.guns.api.item.nbt.GunItemDataAccessor;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.init.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.RegistryObject;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.EnumMap;

import static com.synkra.fawemixinmod.tacz.GunDurabilityManager.setDurability;
import static com.synkra.fawemixinmod.tacz.GunDurabilityManager.setMaxDurability;
import static com.synkra.fawemixinmod.tacz.GunRankingManager.setGunRanking;

@Mixin(GunItemBuilder.class)
public abstract class GunItemBuilderMixinOverwrite {

    // 阴影字段 - 需要访问原类的私有字段
    @Shadow(remap = false)
    private ResourceLocation gunId;

    @Shadow(remap = false)
    private boolean heatData;

    @Shadow(remap = false)
    private int count;

    @Shadow(remap = false)
    private int ammoCount;

    @Shadow(remap = false)
    private boolean bulletInBarrel;

    @Shadow(remap = false)
    private com.tacz.guns.api.item.gun.FireMode fireMode;

    @Shadow(remap = false)
    private EnumMap<AttachmentType, ResourceLocation> attachments;


    /**
     * @author Synkra
     * @reason 给予耐久度
     */
    @Overwrite(remap = false)
    public ItemStack forceBuild() {
        ItemStack gun = new ItemStack(ModItems.MODERN_KINETIC_GUN.get(), this.count);
        if (gun.getItem() instanceof IGun iGun) {
            iGun.setGunId(gun, this.gunId);
            iGun.setFireMode(gun, this.fireMode);
            iGun.setCurrentAmmoCount(gun, this.ammoCount);
            iGun.setBulletInBarrel(gun, this.bulletInBarrel);
            if(heatData) iGun.setHeatAmount(gun, 0f);
            // 设置默认耐久度和最大耐久度
            int initialDurability = GunDurabilityManager.calculateInitialDurability(this.gunId);
            setDurability(gun, initialDurability);
            setMaxDurability(gun, initialDurability);
            // 设置枪械分级
            if (iGun instanceof GunItemDataAccessor dataAccessor) {
                GunRarity rarity = GunRankingManager.getGunRarity(this.gunId);
                int ranking = GunRankingManager.getGunRankingValue(rarity);
                setGunRanking(gun, ranking);
            }
            this.attachments.forEach((type, id) -> {
                ItemStack attachmentStack = AttachmentItemBuilder.create().setId(id).build();
                iGun.installAttachment(gun, attachmentStack);
            });
        }
        return gun;
    }
    /**
     * @author Synkra
     * @reason 给予耐久度
     */
    @Overwrite(remap = false)
    public ItemStack build() {
        String itemType = TimelessAPI.getCommonGunIndex(gunId).map(index -> index.getPojo().getItemType()).orElse(null);
        if (itemType == null) {
            return ItemStack.EMPTY;
        }

        RegistryObject<? extends AbstractGunItem> gunItemRegistryObject = GunItemManager.getGunItemRegistryObject(itemType);
        if (gunItemRegistryObject == null) {
            return ItemStack.EMPTY;
        }

        ItemStack gun = new ItemStack(gunItemRegistryObject.get(), this.count);
        if (gun.getItem() instanceof IGun iGun) {
            iGun.setGunId(gun, this.gunId);
            iGun.setFireMode(gun, this.fireMode);
            iGun.setCurrentAmmoCount(gun, this.ammoCount);
            iGun.setBulletInBarrel(gun, this.bulletInBarrel);
            if(heatData) iGun.setHeatAmount(gun, 0f);
            // 设置默认耐久度和最大耐久度
            int initialDurability = GunDurabilityManager.calculateInitialDurability(this.gunId);
            setDurability(gun, initialDurability);
            setMaxDurability(gun, initialDurability);
            // 设置枪械分级
            if (iGun instanceof GunItemDataAccessor dataAccessor) {
                GunRarity rarity = GunRankingManager.getGunRarity(this.gunId);
                int ranking = GunRankingManager.getGunRankingValue(rarity);
                setGunRanking(gun, ranking);
            }
            this.attachments.forEach((type, id) -> {
                ItemStack attachmentStack = AttachmentItemBuilder.create().setId(id).build();
                iGun.installAttachment(gun, attachmentStack);
            });
        }
        return gun;
    }
}