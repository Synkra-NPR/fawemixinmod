package com.synkra.fawemixinmod.mixin.tacz;

import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.gui.overlay.GunHudOverlay;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.synkra.fawemixinmod.tacz.GunDurabilityManager.getDurability;
import static com.synkra.fawemixinmod.tacz.GunDurabilityManager.getMaxDurability;

@Mixin(value = GunHudOverlay.class, priority = 500) // 关键：降低优先级
public abstract class GunHudOverlayMixin {

    @Inject(method = "render", at = @At(value = "INVOKE",
            target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V",
            ordinal = 1, shift = At.Shift.AFTER)) // 在绘制备弹后执行
    private void addDurabilityNextToAmmo(ForgeGui gui, GuiGraphics graphics, float partialTick, int width, int height, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;

        if (!(player instanceof IClientPlayerGunOperator)) return;
        ItemStack stack = player.getMainHandItem();
        if (!(stack.getItem() instanceof IGun)) return;

        // 获取耐久度
        int durability = getDurability(stack);
        int maxDurability = getMaxDurability(stack);
        if (maxDurability <= 0) return;

        double durabilityPercent = (double) durability / maxDurability;
        String durabilityText = String.format("%.0f%%", durabilityPercent * 100);
        int color = durabilityPercent > 0.25 ? 0xAAAAAA : 0xFF5555;

        Font font = mc.font;
        graphics.pose().pushPose();
        graphics.pose().scale(0.8f, 0.8f, 1); // 和备弹同样大小

        // 计算位置：在备弹右边
        // 原代码中备弹位置：(width - 68 + font.width(currentAmmoCountText) * 1.5f) / 0.8f
        // 我们不知道currentAmmoCountText，所以简单估算
        int x = (int)((width - 68 + font.width("XXXX-") * 1.5f) / 0.8f);
        int y = (int)((height - 36) / 0.8f);

        graphics.drawString(font, durabilityText, x, y, color, false);
        graphics.pose().popPose();
    }
}