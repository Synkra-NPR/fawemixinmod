package com.synkra.fawemixinmod.mixin.tacz;

import com.synkra.fawemixinmod.tacz.GunRankingManager;
import com.synkra.fawemixinmod.tacz.GunRarity;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.api.item.gun.AbstractGunItem;
import com.tacz.guns.api.item.gun.FireMode;
import com.tacz.guns.api.item.nbt.GunItemDataAccessor;
import com.tacz.guns.compat.kubejs.util.AttachmentNbtFactory;
import com.tacz.guns.compat.kubejs.util.GunNbtFactory;
import com.tacz.guns.compat.kubejs.util.TimelessItemType;
import com.tacz.guns.item.AttachmentItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.EnumMap;

import static com.synkra.fawemixinmod.tacz.GunRankingManager.setGunRanking;

@Mixin(GunNbtFactory.class)
public class GunNbtFactoryMixinOverwrite  extends TimelessItemNbtFactoryMixin<AbstractGunItem, GunNbtFactory> {
    @Shadow(remap = false)
    private int ammoCount = 0;
    @Shadow(remap = false)
    private FireMode fireMode;
    @Shadow(remap = false)
    private boolean bulletInBarrel = false;
    @Shadow(remap = false)
    private EnumMap<AttachmentType, ResourceLocation> attachments;
    /**
     * @author Synkra
     * @reason 保证额外添加的nbt正常
     */
    @Overwrite(remap = false)
    public ItemStack build() {
        ItemStack stack = new ItemStack(item, count);
        if (item instanceof IGun iGun) {
            iGun.setGunId(stack, id);
            iGun.setFireMode(stack, fireMode);
            iGun.setCurrentAmmoCount(stack, ammoCount);
            iGun.setBulletInBarrel(stack, bulletInBarrel);
            // 设置枪械分级
            if (iGun instanceof GunItemDataAccessor dataAccessor) {
                GunRarity rarity = GunRankingManager.getGunRarity(this.id);
                int ranking = GunRankingManager.getGunRankingValue(rarity);
                setGunRanking(stack, ranking);
            }
            attachments.forEach((attachmentType, attachmentId) -> {
                ItemStack attachmentStack = new AttachmentNbtFactory((AttachmentItem) TimelessItemType.ATTACHMENT.getItem())
                        .setId(attachmentId)
                        .build();
                iGun.installAttachment(stack, attachmentStack);
            });
        }
        return stack;
    }
}
