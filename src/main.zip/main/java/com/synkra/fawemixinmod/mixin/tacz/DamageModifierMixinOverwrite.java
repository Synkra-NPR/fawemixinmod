package com.synkra.fawemixinmod.mixin.tacz;

import com.synkra.fawemixinmod.tacz.GunRankingManager;
import com.synkra.fawemixinmod.tacz.GunRarity;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.gun.FireMode;
import com.tacz.guns.api.modifier.IAttachmentModifier;
import com.tacz.guns.config.sync.SyncConfig;
import com.tacz.guns.resource.modifier.AttachmentCacheProperty;
import com.tacz.guns.resource.modifier.custom.DamageModifier;
import com.tacz.guns.resource.pojo.data.gun.BulletData;
import com.tacz.guns.resource.pojo.data.gun.ExtraDamage;
import com.tacz.guns.resource.pojo.data.gun.GunData;
import com.tacz.guns.resource.pojo.data.gun.GunFireModeAdjustData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

@Mixin(DamageModifier.class)
public class DamageModifierMixinOverwrite {
    /**
     * @author Synkra
     * @reason 修正伤害
     */
    @OnlyIn(Dist.CLIENT)
    @Overwrite(remap = false)
    public List<IAttachmentModifier.DiagramsData> getPropertyDiagramsData(ItemStack gunItem, GunData gunData, AttachmentCacheProperty cacheProperty) {
        // 必要数据获取
        LinkedList<ExtraDamage.DistanceDamagePair> damagePairModifier = cacheProperty.getCache(DamageModifier.ID);
        IGun iGun = Objects.requireNonNull(IGun.getIGunOrNull(gunItem));
        FireMode fireMode = iGun.getFireMode(gunItem);
        BulletData bulletData = gunData.getBulletData();
        GunFireModeAdjustData fireModeAdjustData = gunData.getFireModeAdjustData(fireMode);

        // 获取最原始的数值
        float rawDamage = bulletData.getDamageAmount();
        // 额外伤害
        ExtraDamage extraDamage = bulletData.getExtraDamage();
        // 开火模式调整
        // 最终的 base 伤害
        float finalBase = fireModeAdjustData != null ? fireModeAdjustData.getDamageAmount() : 0f;
        if (extraDamage != null && extraDamage.getDamageAdjust() != null) {
            finalBase += extraDamage.getDamageAdjust().get(0).getDamage();
        } else {
            finalBase += rawDamage;
        }
        finalBase *= SyncConfig.DAMAGE_BASE_MULTIPLIER.get();
        float modifiedValue = damagePairModifier.get(0).getDamage();
        float modifier = modifiedValue - finalBase;

        // 根据枪械稀有度调整伤害显示
        ResourceLocation gunId = iGun.getGunId(gunItem);
        GunRarity gunRarity = GunRankingManager.getGunRarity(gunId);
        float damageMultiplier = GunRankingManager.getDamageMultiplier(gunRarity);
        modifiedValue *= damageMultiplier;
        finalBase *= damageMultiplier;
        modifier *= damageMultiplier;

        double percent = Math.min(finalBase / 50.0, 1);
        double modifierPercent = Math.min(modifier / 50.0, 1);

        String titleKey = "gui.tacz.gun_refit.property_diagrams.damage";
        String positivelyString = String.format("%.2f §a(+%.2f)", modifiedValue, modifier);
        String negativelyString = String.format("%.2f §c(%.2f)", modifiedValue, modifier);
        String defaultString = String.format("%.2f", modifiedValue);
        boolean positivelyBetter = true;

        IAttachmentModifier.DiagramsData diagramsData = new IAttachmentModifier.DiagramsData(percent, modifierPercent, modifier, titleKey, positivelyString, negativelyString, defaultString, positivelyBetter);
        return Collections.singletonList(diagramsData);
    }
}
