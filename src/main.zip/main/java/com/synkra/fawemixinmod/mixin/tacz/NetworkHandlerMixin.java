package com.synkra.fawemixinmod.mixin.tacz;

import com.synkra.fawemixinmod.tacz.network.message.GunRankingPacket;
import com.synkra.fawemixinmod.tacz.network.message.KillFeedPacket;
import com.tacz.guns.network.NetworkHandler;
import net.minecraftforge.network.simple.SimpleChannel;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import net.minecraftforge.network.NetworkDirection;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mixin(NetworkHandler.class)
public class NetworkHandlerMixin {
@Final
    @Shadow(remap = false)
    public static SimpleChannel CHANNEL;
    @Final
    @Shadow(remap = false)
    private static AtomicInteger ID_COUNT;
    @Inject(
            method = "init",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/tacz/guns/network/NetworkHandler;registerAcknowledge()V"
            ),
            remap = false
    )
    private static void injectCustomMessages(CallbackInfo ci) {
        // 这里注入你的代码
        CHANNEL.registerMessage(ID_COUNT.getAndIncrement(), GunRankingPacket.class,
                GunRankingPacket::encode, GunRankingPacket::decode, GunRankingPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        CHANNEL.registerMessage(ID_COUNT.getAndIncrement(), KillFeedPacket.class,
                KillFeedPacket::encode, KillFeedPacket::decode, KillFeedPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }
}
