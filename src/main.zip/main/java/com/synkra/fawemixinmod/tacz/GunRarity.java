package com.synkra.fawemixinmod.tacz;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.awt.Color;
/**
 * 枪械稀有度
 */
public enum GunRarity {
    COMMON(0xD9D9D9, "common"),          // 普通
    UNCOMMON(0x64D679, "uncommon"),      // 优秀
    RARE(0x3282F6, "rare"),              // 精良
    EPIC(0xC635D1, "epic"),              // 史诗
    LEGENDARY(0xF09B59, "legendary"),    // 传说
    MYTHIC(0xBD291D, "mythic"),          // 神话
    IMMORTAL(0xFFFD55, "immortal"),      // 不朽
    ABNORMAL(0xAAAAAA, "abnormal");      // 异常

    private final int colorValue;
    private final String nameKey;



    GunRarity(int colorValue, String nameKey) {
        this.colorValue = colorValue;
        this.nameKey = nameKey;
    }

    public int getColorValue() {
        return colorValue;
    }

    public String getNameKey() {
        return nameKey;
    }
    /**
     * 获取稀有度的显示名称
     *
     * @return 包含颜色的显示名称组件
     */
    public MutableComponent getDisplayName() {
        return Component.literal("[").withStyle(style -> style.withColor(colorValue)).append(Component.translatable("tooltip.fawemixinmod.tacz.gun.rarity." + nameKey))
                .withStyle(style -> style.withColor(colorValue)).append(Component.literal("]").withStyle(style -> style.withColor(colorValue)));
//        return Component.translatable("tooltip.fawemixinmod.tacz.gun.rarity." + nameKey)
//                .withStyle(style -> style.withColor(colorValue));
    }
    /**
     * 根据百分比获取稀有度
     *
     * @param percent 百分比值（0-1之间）
     * @return 对应的稀有度枚举值
     */
    public static GunRarity getRarityByPercent(double percent) {
        if (percent < 0.1) {
            return IMMORTAL;      // 前10% 不朽
        } else if (percent < 0.2) {
            return MYTHIC;        // 10%-20% 神话
        } else if (percent < 0.32) {
            return LEGENDARY;     // 20%-32% 传说
        } else if (percent < 0.45) {
            return EPIC;          // 32%-45% 史诗
        } else if (percent < 0.60) {
            return RARE;          // 45%-60% 精良
        } else if (percent < 0.80) {
            return UNCOMMON;      // 60%-80% 优秀
        } else {
            return COMMON;        // 80%-100% 普通
        }
    }
}