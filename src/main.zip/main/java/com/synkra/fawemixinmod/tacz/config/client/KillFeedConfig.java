package com.synkra.fawemixinmod.tacz.config.client;

import net.minecraftforge.common.ForgeConfigSpec;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class KillFeedConfig {
public static ForgeConfigSpec.BooleanValue ENABLED;
    public static ForgeConfigSpec.IntValue MAX_ENTRIES;
    public static ForgeConfigSpec.IntValue DURATION_MILLISECONDS;
    public static ForgeConfigSpec.IntValue POSITION_X_OFFSET;
    public static ForgeConfigSpec.IntValue POSITION_Y_OFFSET;
    public static ForgeConfigSpec.DoubleValue SCALE;

    public static final ForgeConfigSpec SPEC;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        init(builder);
        SPEC = builder.build();
    }

    public static void init(ForgeConfigSpec.Builder builder) {
        builder.push("kill_feed");

        builder.comment("Whether or not to display the kill feed");
        ENABLED = builder.define("Enabled", true);

        builder.comment("Maximum number of kill feed entries to display");
        MAX_ENTRIES = builder.defineInRange("MaxEntries", 12, 1, 100);

        builder.comment("Duration of each kill feed entry in milliseconds");
        DURATION_MILLISECONDS = builder.defineInRange("DurationMilliseconds", 5000, 1000, 30000);

        builder.comment("X offset from the right side of the screen");
        POSITION_X_OFFSET = builder.defineInRange("PositionXOffset", 0, -1000, 1000);

        builder.comment("Y offset from the top of the screen");
        POSITION_Y_OFFSET = builder.defineInRange("PositionYOffset", 60, 0, 1000);

        builder.comment("Scale of the kill feed entries");
        SCALE = builder.defineInRange("Scale", 1.0, 0.1, 5.0);

        builder.pop();
    }
}