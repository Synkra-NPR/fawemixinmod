package com.synkra.fawemixinmod.tacz.network.message;

import com.synkra.fawemixinmod.tacz.client.gui.overlay.KillFeedOverlay;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class KillFeedPacket {
    private final String killerName;
    private final String victimName;
    private final ItemStack weapon;
    private final boolean isKillerPlayer;

    public KillFeedPacket(String killerName, String victimName, ItemStack weapon, boolean isKillerPlayer) {
        this.killerName = killerName;
        this.victimName = victimName;
        this.weapon = weapon.copy();
        this.isKillerPlayer = isKillerPlayer;
    }

    public static void encode(KillFeedPacket message, FriendlyByteBuf buf) {
        buf.writeUtf(message.killerName);
        buf.writeUtf(message.victimName);
        buf.writeItem(message.weapon);
        buf.writeBoolean(message.isKillerPlayer);
    }

    public static KillFeedPacket decode(FriendlyByteBuf buf) {
        String killerName = buf.readUtf();
        String victimName = buf.readUtf();
        ItemStack weapon = buf.readItem();
        boolean isKillerPlayer = buf.readBoolean();
    return new KillFeedPacket(killerName, victimName, weapon, isKillerPlayer);
    }

    public static void handle(KillFeedPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            // 在客户端处理消息
            KillFeedOverlay.getInstance().addKillEntry(
                    message.killerName,
                    message.victimName,
                    message.weapon,
                    message.isKillerPlayer
            );
        });
        context.setPacketHandled(true);
    }

    public String getKillerName() {
        return killerName;
    }

    public String getVictimName() {
        return victimName;
    }

    public ItemStack getWeapon() {
        return weapon;
    }

    public boolean isKillerPlayer() {
        return isKillerPlayer;
    }
}