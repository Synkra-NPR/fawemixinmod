package com.synkra.fawemixinmod.tacz.api.event.common;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.Cancelable;
import net.minecraftforge.eventbus.api.Event;

/**
 * 枪械配方拦截事件，在枪械配方初始化前触发
 * 可以通过setCanceled(true)取消配方注册过程
 */
@Cancelable
public class GunRecipeInterceptEvent extends Event {
    private final ResourceLocation recipeId;
    private final Object recipe;

    public GunRecipeInterceptEvent(ResourceLocation recipeId, Object recipe) {
        this.recipeId = recipeId;
        this.recipe = recipe;
    }

    public ResourceLocation getRecipeId() {
        return recipeId;
    }

    public Object getRecipe() {
        return recipe;
    }
}