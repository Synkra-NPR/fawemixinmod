package com.synkra.fawemixinmod.tacz.util;

import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.gun.FireMode;
import com.tacz.guns.resource.modifier.AttachmentPropertyManager;
import com.tacz.guns.resource.modifier.custom.RpmModifier;
import com.tacz.guns.resource.pojo.data.attachment.Modifier;
import com.tacz.guns.resource.pojo.data.gun.GunData;
import com.tacz.guns.util.AttachmentDataUtils;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import static com.tacz.guns.resource.modifier.AttachmentPropertyManager.getModifiers;

public class OtherUtil {
    public static int getRPM(ItemStack gunItem, GunData gunData){
        IGun iGun = IGun.getIGunOrNull(gunItem);
        if (iGun == null) {
            return 300;
        }
        FireMode fireMode = iGun.getFireMode(gunItem);
        int roundsPerMinute = gunData.getRoundsPerMinute(fireMode);
        Class<?> targetClass = AttachmentDataUtils.class;
        try {
            Method privateStaticMethod = targetClass.getDeclaredMethod(
                    "getModifiers",
                    ItemStack.class ,
                    GunData.class,
                    String.class
            );
            privateStaticMethod.setAccessible(true);
            List<Modifier> modifiers = (List<Modifier>)privateStaticMethod.invoke(null, gunItem, gunData, RpmModifier.ID);
            double eval = AttachmentPropertyManager.eval(modifiers, roundsPerMinute);
            return (int) Math.round(eval);
        }catch (NoSuchMethodException e){
            return roundsPerMinute;
        } catch (InvocationTargetException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
