package com.synkra.fawemixinmod.tacz.event;

import com.synkra.fawemixinmod.tacz.api.event.common.GunRecipeInterceptEvent;
import com.tacz.guns.crafting.GunSmithTableRecipe;
import com.tacz.guns.crafting.result.GunSmithTableResult;
import com.tacz.guns.crafting.result.RawGunTableResult;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.lang.reflect.Field;

@Mod.EventBusSubscriber
public class GunRecipeInterceptHandler {

    /**
     * 拦截枪械配方注册事件
     * 通过取消事件来阻止配方初始化
     */
    @SubscribeEvent
    public static void onGunRecipeIntercept(GunRecipeInterceptEvent event) {
        // 只拦截枪械配方，不拦截配件、子弹等其他配方
        Object recipe = event.getRecipe();
        if (recipe instanceof GunSmithTableRecipe gunRecipe) {
            GunSmithTableResult result = gunRecipe.getResult();
            // 通过反射获取RawGunTableResult字段
            try {
                Field rawField = GunSmithTableResult.class.getDeclaredField("raw");
                rawField.setAccessible(true);
                Object raw = rawField.get(result);

                // 如果是枪械配方，则拦截
                if (raw instanceof RawGunTableResult rawGunTableResult) {
                    // 获取类型字段
                    Field typeField = RawGunTableResult.class.getDeclaredField("type");
                    typeField.setAccessible(true);
                    String type = (String) typeField.get(rawGunTableResult);

                    // 只拦截枪械类型配方
                    if (GunSmithTableResult.GUN.equals(type)) {
                        event.setCanceled(true);
                    }
                }
            } catch (Exception e) {
                // 发生异常时不拦截任何配方
                e.printStackTrace();
            }
        }
    }
}